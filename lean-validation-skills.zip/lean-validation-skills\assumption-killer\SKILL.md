---
name: assumption-killer
description: >
  Step 3 of 6 in the Lean Validation Pipeline. Applies The Lean Startup's
  validated learning engine: surfaces every assumption hiding in your idea,
  ranks them by risk, designs the cheapest possible test for each, runs the
  build-measure-learn loop, and delivers a pivot-or-persevere decision.
  Saves as assumption_tests.md.
---

# Assumption Killer

Every startup plan is a stack of assumptions.
"People have this problem." (Assumption.)
"They will pay to solve it." (Assumption.)
"Our solution solves it." (Assumption.)
"We can reach these people." (Assumption.)
"They will choose us over the alternative." (Assumption.)
Every single one could be wrong. Most are.
The Lean Startup is not about building fast. It is about learning fast.
You do not need to build the product to test the assumption.
You need to design the cheapest test that could prove you wrong.
If it survives the test, it is a validated learning. Not a fact. A learning.
Save as `assumption_tests.md`.

---

## The Lean Startup Core Engine

```
BUILD → MEASURE → LEARN → (repeat)

The mistake most people make: they BUILD first, then discover
their assumptions were wrong after spending months on the wrong thing.

The Lean Startup inverts this:
  LEARN first (what must be true for this to work?)
  MEASURE the riskiest assumption (design the cheapest test)
  BUILD only what is necessary to run the test

THE PIVOT OR PERSEVERE DECISION:
  After every test, you have ONE decision:
  PERSEVERE: test confirmed the assumption. Move to the next one.
  PIVOT:     test falsified the assumption. Change the idea before building more.

A pivot is not failure. A pivot is learning at minimum cost.
Failure is building for 6 months on a false assumption you never tested.
```

---

## Step 1 — Surface Every Assumption

```
READ: angle_map.md → your unique angle statement
READ: interview_plan.md → your interview verdict and patterns

FOR YOUR IDEA, COMPLETE EVERY LINE:

CUSTOMER ASSUMPTIONS:
  "I believe [specific audience] experiences [specific problem]."
  "I believe this problem is frequent enough that they actively seek solutions."
  "I believe this problem is painful enough that they would pay to fix it."
  "I believe I can reach these people through [specific channel]."
  "I believe there are enough of them to build a sustainable business."

PROBLEM ASSUMPTIONS:
  "I believe the core problem is [X], not [Y] (which is what competitors solve)."
  "I believe current solutions fail because [specific reason]."
  "I believe the workaround people use is [X], which is worse than my solution."

SOLUTION ASSUMPTIONS:
  "I believe [my solution] actually solves the problem as described."
  "I believe people can use [my solution] without significant training."
  "I believe [my solution] delivers the outcome faster/cheaper/better than alternatives."

BUSINESS ASSUMPTIONS:
  "I believe people will pay $[X] for this."
  "I believe I can deliver this at a cost that leaves profit."
  "I believe customers will come back / refer others / expand their use."

GROWTH ASSUMPTIONS:
  "I believe I can acquire customers through [channel] at a cost I can sustain."
  "I believe word of mouth will work in this market."
  "I believe the market is large enough to reach $[X] revenue."

LIST ALL YOUR ASSUMPTIONS:
  Write every single one. Minimum 10. No editing. If it is in the plan, it is an assumption.
```

---

## Step 2 — Rank by Risk

```
FOR EACH ASSUMPTION, SCORE ON TWO DIMENSIONS:

  CONFIDENCE (how sure are you?):
    1 = total guess, never tested
    2 = seems reasonable, some indirect evidence
    3 = directly confirmed in interviews or existing research

  IMPACT IF WRONG (how badly does it hurt?):
    1 = annoying but we adapt
    2 = major change needed to business model
    3 = idea is dead if this is false

  RISK SCORE = (3 - confidence) × impact
  High risk score = test this FIRST

HIGHEST RISK ASSUMPTION = your riskiest assumption (RA)
  This is the one assumption that, if wrong, kills everything else.
  Eric Ries calls this the "leap of faith assumption."
  It is usually one of:
    → "People have this problem" (customer problem assumption)
    → "People will pay for this" (willingness to pay assumption)
    → "Our solution actually works" (solution efficacy assumption)

RANK YOUR TOP 5 RISKIEST ASSUMPTIONS:
  | # | Assumption | Confidence | Impact | Risk Score |
  |---|------------|------------|--------|------------|
  | 1 |            |            |        |            |
  | 2 |            |            |        |            |
  | 3 |            |            |        |            |
  | 4 |            |            |        |            |
  | 5 |            |            |        |            |
```

---

## Step 3 — Design Tests (Cheapest Proof of Wrong)

```
THE TEST DESIGN PRINCIPLE:
  "What is the smallest, cheapest thing I can do in the next 7 days
   that would prove this assumption FALSE?"

NOT: build the full product and see if people use it.
YES: build the minimum possible version that tests only this assumption.

RIES'S MVP TYPES (choose the right test for each assumption):

  CONCIERGE MVP (best for "does this solution actually help?"):
    Do the service manually for one person, by hand, before building automation.
    You are the product. See if manually doing it helps them.
    Example: Instead of building a budgeting app, do one person's budget
             manually in a spreadsheet and get on a call to review it with them.

  WIZARD OF OZ MVP (best for "will people pay for X?"):
    Build the front end. Do the back end manually.
    Customer sees a product. You are running it by hand behind the scenes.
    Example: Build a "product recommendation" page. Customer submits preferences.
             You personally email them recommendations. They think it's automated.

  LANDING PAGE MVP (best for "will people click to learn more / sign up?"):
    Build a one-page description of the product that doesn't exist yet.
    Include a price. Include a "Buy Now" or "Join the waitlist" button.
    Measure: how many people who land on the page click the button?
    If less than 2–5% click: the message or offer is wrong.
    Example: Carrd or Notion page, no code required.

  PITCH MVP (best for "will people pay before it exists?"):
    Pitch the product in a sales conversation. Ask for money.
    If they will not pay for it now, they will not pay for it when you build it.
    A verbal yes is not validation. A payment is.

  SMOKE TEST / AD MVP (best for "can I reach this audience?"):
    Run a $20 Facebook or Reddit ad to your landing page.
    Measure: cost per click, cost per sign-up.
    If nobody clicks: either the audience targeting or the message is wrong.

FOR EACH OF YOUR TOP 5 ASSUMPTIONS, WRITE:
  Assumption: [state it]
  Test type:  [concierge / wizard of oz / landing page / pitch / ad]
  What you will build: [specific, cheapest version]
  How you will measure: [one clear metric]
  What "confirmed" looks like: [specific threshold]
  What "falsified" looks like: [specific threshold]
  Time to run test: [days]
  Cost to run test: [$X or 0]
```

---

## Step 4 — The Build-Measure-Learn Log

```
RUN ONE TEST AT A TIME, STARTING WITH THE RISKIEST ASSUMPTION.

FOR EACH TEST, RECORD:

  TEST #[N]
  Assumption tested: [state it]
  Test type: [type]
  What we built: [describe the minimum artifact]
  Metric tracked: [one number]
  Threshold: confirmed at [X], falsified at [Y]
  Duration: [start date – end date]
  Result: [actual number]
  Verdict: CONFIRMED / FALSIFIED / INCONCLUSIVE

  If CONFIRMED:
    → What did we learn? [1 sentence]
    → Next test: [which assumption is next riskiest?]

  If FALSIFIED:
    → What does this change? [1 sentence]
    → Pivot required: [describe the change to the idea]
    → New assumption to test first: [restated or new assumption]

  If INCONCLUSIVE:
    → What made the test invalid? [data quality / wrong audience / wrong metric]
    → How to redesign the test? [specific change]

THE PIVOT TYPES (from Ries — when falsified, choose your pivot):
  ZOOM-IN PIVOT: One feature becomes the whole product
  ZOOM-OUT PIVOT: What you thought was the whole product becomes one feature
  CUSTOMER SEGMENT PIVOT: Right solution, wrong customer
  CUSTOMER NEED PIVOT: Solving a different problem for the same customer
  PLATFORM PIVOT: Application → platform (or reverse)
  BUSINESS ARCHITECTURE PIVOT: High-margin low-volume ↔ Low-margin high-volume
  CHANNEL PIVOT: Different go-to-market route
  ENGINE OF GROWTH PIVOT: Paid → viral → sticky growth engine
```

---

## Step 5 — Pivot or Persevere Decision

```
AFTER TESTING YOUR TOP 3 ASSUMPTIONS, MAKE THE FORMAL DECISION:

PERSEVERE SIGNALS:
  ✓ At least 2 of 3 riskiest assumptions confirmed
  ✓ Interview patterns match test results
  ✓ At least one person paid or strongly committed
  ✓ You can see a clear path to the next test

PIVOT SIGNALS:
  ✗ Riskiest assumption falsified
  ✗ Customers like the product but won't pay for it
  ✗ Customers pay but don't come back (retention signal)
  ✗ Acquisition cost is 5× the lifetime value
  ✗ You consistently find a different problem worth solving in interviews

ABANDON SIGNALS:
  ✗ Nobody has the problem
  ✗ Problem exists but nobody cares enough to pay or change behaviour
  ✗ Market too small to ever reach sustainability
  ✗ Competitor has such a dominant advantage that differentiation is impossible

THE DECISION:
  [ ] PERSEVERE → proceed to MVP Sprint with these validated learnings
  [ ] PIVOT TYPE: [name the pivot type] → restate idea, re-run from Step 1
  [ ] ABANDON → document why, move to next idea
```

---

## Output File: assumption_tests.md

```markdown
# Assumption Tests
Pipeline step: 3 of 6
Date: [date]
Idea: [from angle_map.md]

---

## All Assumptions Listed
[full list, minimum 10]

## Top 5 Riskiest Assumptions
| # | Assumption | Confidence | Impact | Risk Score |
[table]

## Test Designs
[For each of top 5: type, build, metric, threshold, time, cost]

## Build-Measure-Learn Log
[One entry per completed test]

## Pivot or Persevere Decision
Decision       : PERSEVERE / PIVOT / ABANDON
Pivot type     : [if pivot]
Reasoning      : [2–3 sentences grounded in test results]
Validated facts: [list what is now confirmed true]

---

## Pipeline Status
Step 1 ✅ steal-the-angle   → angle_map.md
Step 2 ✅ mom-test-master   → interview_plan.md
Step 3 ✅ assumption-killer → assumption_tests.md
Step 4 ⬜ mvp-sprint        → mvp_spec.md
Step 5 ⬜ message-maker     → message_kit.md
Step 6 ⬜ first-sale-engine → sales_plan.md
```

---

## Review Gate (MANDATORY)

After saving `assumption_tests.md`, present this EXACTLY:

```
✅ Assumption tests complete. Saved to assumption_tests.md.

📋 Summary:
- Assumptions surfaced  : [N]
- Riskiest assumption   : [state it]
- Tests designed        : [N]
- Tests completed       : [N]
- Confirmed assumptions : [N]
- Falsified assumptions : [N]
- Decision              : PERSEVERE / PIVOT [type] / ABANDON
- Validated learnings   : [list]

👉 You can:
  - Approve → say "approved" or "build the mvp"
  - Add a test result → say "test result: [assumption], [result], [metric]"
  - Log a pivot → say "pivot: [type], [new framing]"

⏸️ Waiting for approval before MVP Sprint runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the mvp`, `mvp sprint`,
`proceed`, `next`, `go`, `assumptions cleared`, `sprint`

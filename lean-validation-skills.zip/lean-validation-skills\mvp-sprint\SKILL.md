---
name: mvp-sprint
description: >
  Step 4 of 6 in the Lean Validation Pipeline. Applies The Lean Startup's
  Minimum Viable Product methodology: defines the minimum version of the
  product that tests the core hypothesis, strips every feature that is not
  the riskiest test, specifies what to build, and sets the success metrics
  for the first real cohort of users. Saves as mvp_spec.md.
---

# MVP Sprint

An MVP is not a bad product.
An MVP is not "the full product but with fewer features."
An MVP is the smallest thing that can answer the most important question.
Most people build too much. They add features the customer never asked for.
They spend 3 months building what could have been tested in 3 weeks.
The MVP Sprint exists to prevent that.
Strip everything that is not the test.
Build only what answers the riskiest surviving assumption.
Measure ruthlessly. Save as `mvp_spec.md`.

---

## Prerequisites

```
READ FIRST: angle_map.md         → your unique angle, the remix
READ SECOND: interview_plan.md   → validated customer quotes, real language
READ THIRD: assumption_tests.md  → validated learnings, confirmed/falsified,
                                   pivot or persevere decision
```

---

## Step 1 — The MVP Decision: What Are You Testing?

```
THE MVP QUESTION:
  "What is the one thing the MVP must answer that nothing else can?"

This is NOT: "What is the minimum feature set for a usable product?"
This IS: "What is the smallest version that tests whether this idea
          is fundamentally sound?"

FROM RIES:
  "The minimum viable product is that version of a new product which allows
   a team to collect the maximum amount of validated learning about customers
   with the least effort."

THE RULE: If a feature does not help answer the core question, cut it.

WHAT IS YOUR CORE QUESTION?
  Choose ONE:
  → "Will people pay $[X] for this?" (willingness to pay MVP)
  → "Does this solution actually solve the problem?" (efficacy MVP)
  → "Can we acquire customers at a sustainable cost?" (channel MVP)
  → "Will people come back after using it once?" (retention MVP)
  → "Will users refer others without being asked?" (viral MVP)

YOUR CORE QUESTION: [write it here, before anything else]
```

---

## Step 2 — The Feature Audit

```
LIST EVERY FEATURE YOU ORIGINALLY PLANNED:
  [dump every feature you have ever thought about for this product]

NOW AUDIT EACH FEATURE:

  FOR EACH FEATURE, ASK:
    "Does this feature directly help answer the core question?"
    If NO → cut it from the MVP. Add it to the backlog.
    If YES → keep it.

  THE THREE LISTS:
    MVP (must have — directly tests the core question):
      [list of features]

    PHASE 2 (nice to have — adds value but not needed to test core question):
      [list of features]

    NEVER (things you planned but no customer asked for):
      [list of features]

THE RATCHET RULE:
  After cutting, look at the MVP list again.
  "If I had to cut one more thing, what would it be?"
  Cut it.
  Repeat until cutting any further would break the test.

A GOOD MVP:
  → Can be built in days or weeks, not months
  → Looks slightly embarrassing (if it doesn't, you built too much)
  → Directly answers the core question
  → Can be shown to a real customer for a real reaction
```

---

## Step 3 — Define the MVP Format

```
CHOOSE THE RIGHT TYPE OF MVP FOR YOUR CORE QUESTION:

  TYPE A — LANDING PAGE MVP (testing: will people want this / sign up?)
    Build: 1-page site with headline, description, benefit bullets, CTA
    Measure: conversion rate (visitors → sign-up / waitlist / payment)
    Tools: Carrd, Notion, Typedream, Framer (all free or near-free)
    Timeline: 1–3 days
    Success: 5%+ of visitors take the target action

  TYPE B — CONCIERGE MVP (testing: does the solution actually help?)
    Build: do the service manually for 3–5 people
    You ARE the product. No code. No automation.
    Measure: did it solve the problem? Would they pay for the automated version?
    Timeline: 1–2 weeks
    Success: all 3–5 participants say "yes I would pay $[X] for this automatically"

  TYPE C — WIZARD OF OZ MVP (testing: does the solution work + will they pay?)
    Build: front end (looks automated), back end (you manually do it)
    Customer experiences the product. You run it by hand.
    Measure: payment, retention, referrals
    Timeline: 1–2 weeks
    Success: payment AND return use

  TYPE D — PROTOTYPE / DEMO MVP (testing: is this the right solution design?)
    Build: clickable mockup (Figma, Framer) or working demo of one core flow
    Measure: can users complete the core task? Do they understand it?
    Tools: Figma (free), Framer, Marvel
    Timeline: 2–5 days
    Success: users complete core task without help AND rate it 4+ out of 5

  TYPE E — PRESELL MVP (testing: will people pay before it exists?)
    Build: a pitch deck or 1-page description + price
    Show it to target customers. Ask for money.
    Measure: number of payments or signed letters of intent
    Timeline: 1 day to prepare, 1 week to run
    Success: 1 person pays (or 3 strong verbal commitments with names)
    Rule: verbal "yes" is not validation. Payment is.

YOUR MVP TYPE: [choose one]
```

---

## Step 4 — The MVP Spec

```
BE SPECIFIC. VAGUE MVP SPECS PRODUCE VAGUE PRODUCTS.

NAME: [what you will call this version]
TYPE: [from Step 3]
CORE QUESTION: [from Step 1]

WHAT IT INCLUDES (MVP list from Step 2):
  Feature 1: [description — be specific about what it does and does NOT do]
  Feature 2: [description]
  Feature 3: [description]

WHAT IT EXPLICITLY DOES NOT INCLUDE:
  [list everything you are leaving out of the MVP deliberately]

THE USER JOURNEY (what happens step by step):
  1. User encounters the MVP through [channel]
  2. User sees [what]
  3. User does [what]
  4. User gets [outcome]
  5. User is asked to [action — your measurement point]

BUILD PLAN:
  Who builds it: [you / co-founder / no-code tool / freelancer]
  Tools needed: [list]
  Time to build: [days]
  Cost to build: [$X or 0]

TARGET COHORT:
  Who will test this MVP: [specific description]
  How many: [N — minimum 5, ideally 10–20]
  How you will reach them: [specific method from Mom Test interviews, referrals]
  Timeline: [start date – end date]
```

---

## Step 5 — Success Metrics (Innovation Accounting)

```
RIES'S INNOVATION ACCOUNTING:
  You cannot manage what you don't measure.
  But vanity metrics lie. Set actionable metrics only.

VANITY METRICS (do not use these as success criteria):
  Total signups (not tied to retention)
  Page views
  Social followers
  "Positive feedback" or "people love it"
  Number of features shipped

ACTIONABLE METRICS (use these):
  Activation rate: % of people who signed up and completed the core action
  Retention: % who came back after day 1 / day 7 / day 30
  Revenue: total paid, by cohort
  Referral: % who referred at least one other person
  NPS (net promoter score): "How likely are you to recommend this?" 0–10

FOR YOUR MVP, SET THREE METRICS:

  METRIC 1 (primary — directly answers your core question):
    Name: [e.g. "conversion rate from landing page to payment"]
    How measured: [specific method]
    Success threshold: [X%]
    Failure threshold: [Y%]

  METRIC 2 (secondary — leading indicator of core metric):
    Name: [e.g. "time-on-page before clicking CTA"]
    How measured: [specific method]
    Target: [X]

  METRIC 3 (health check — ensures you are not deceiving yourself):
    Name: [e.g. "did any user complete the core task without help?"]
    How measured: [observation / recording / support tickets]
    Minimum: [X]

COHORT ANALYSIS RULE:
  Compare groups of users who started at the same time.
  Never mix new and old users in the same metric.
  If your month-2 numbers look better than month-1, check: is it
  because the product got better, or because the audience changed?
```

---

## Output File: mvp_spec.md

```markdown
# MVP Specification
Pipeline step: 4 of 6
Date: [date]
Product: [from angle_map.md]

---

## Core Question
[The single question this MVP must answer]

## MVP Type
[Landing page / Concierge / Wizard of Oz / Prototype / Presell]

## Feature Lists
MVP (builds):
  • [feature]
  • [feature]

Phase 2 (backlog):
  • [feature]

Explicitly excluded:
  • [feature]

## User Journey
1. [step]
2. [step]
3. [step]
4. [step — measurement point]

## Build Plan
Builder       : [who]
Tools         : [list]
Build time    : [days]
Build cost    : [$X]
Launch date   : [date]

## Target Cohort
Who           : [description]
How many      : [N]
How to reach  : [method]
Timeline      : [start – end]

## Success Metrics
Primary   : [metric] — success at [X%], failure at [Y%]
Secondary : [metric] — target [X]
Health    : [metric] — minimum [X]

## Pivot or Persevere Trigger
If primary metric hits [X] by [date] → PERSEVERE to Message Maker
If primary metric stays below [Y] by [date] → PIVOT: [which type]

---

## Pipeline Status
Step 1 ✅ steal-the-angle   → angle_map.md
Step 2 ✅ mom-test-master   → interview_plan.md
Step 3 ✅ assumption-killer → assumption_tests.md
Step 4 ✅ mvp-sprint        → mvp_spec.md
Step 5 ⬜ message-maker     → message_kit.md
Step 6 ⬜ first-sale-engine → sales_plan.md
```

---

## Review Gate (MANDATORY)

After saving `mvp_spec.md`, present this EXACTLY:

```
✅ MVP spec complete. Saved to mvp_spec.md.

📋 Summary:
- Core question    : [the question being tested]
- MVP type         : [type]
- Features in MVP  : [N]
- Features cut     : [N]
- Build time       : [days]
- Build cost       : [$X]
- Target cohort    : [N people, via channel]
- Primary metric   : [metric] — success at [X%]
- Launch date      : [date]

Outstanding before build:
  [anything not yet decided]

👉 You can:
  - Approve → say "approved" or "make the message"
  - Cut more features → say "cut [feature]"
  - Change the MVP type → say "switch to [type]"
  - Adjust metrics → say "change primary metric to [X]"

⏸️ Waiting for approval before Message Maker runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `make the message`, `message maker`,
`proceed`, `next`, `go`, `mvp approved`, `build the message`

---
name: mom-test-master
description: >
  Step 2 of 6 in the Lean Validation Pipeline. Applies "The Mom Test" by
  Rob Fitzpatrick: scripts real customer interviews that extract truth instead
  of compliments, asks about past behaviour not future intent, identifies the
  questions you are secretly terrified to ask, and turns interview notes into
  validated insights or pivot signals. Saves as interview_plan.md.
---

# Mom Test Master

Your mum loves you. She will not tell you your idea is bad.
She wants to protect you. So she lies.
Not just your mum. Everyone does this.
Every person you pitch to will be polite. They will say "that sounds interesting."
They will say "I would definitely use that." They will not pay for it.
The Mom Test is the system for asking questions so good
that even a loving mother cannot lie to you.
Not because you trick her. Because you never ask her opinion.
You ask about her life. Save as `interview_plan.md`.

---

## The Core Rules of The Mom Test

```
RULE 1: Talk about their life, not your idea.
  WRONG: "What do you think of my idea?"
  RIGHT: "Walk me through the last time you had to [solve this problem]."

RULE 2: Ask about the past, not the future.
  WRONG: "Would you use this if I built it?"
  RIGHT: "How do you currently handle this? How often does it come up?"

  WHY: Future intent is worthless data. People say yes to avoid conflict.
       Past behaviour is evidence. It already happened. It cannot be a lie.

RULE 3: Ask about specifics, not hypotheticals.
  WRONG: "How much would you pay for something like this?"
  RIGHT: "What are you currently paying to solve this? What did you buy last?"

RULE 4: Opinions are worth nothing. Facts and commitments are worth everything.
  WORTHLESS: "I love it." "That's a great idea." "I'd definitely buy that."
  VALUABLE:  "I spent $300 on [X] last month and it still doesn't work."
             "I do [workaround] every single week because there's nothing better."
             "I'll give you my card right now if you can ship it by [date]."

RULE 5: Shut up and listen. You are not here to sell. You are here to learn.
  You are allowed to ask follow-up questions.
  You are NOT allowed to defend your idea, explain your vision, or pitch.
  The moment you pitch, they switch to telling you what you want to hear.
```

---

## Step 1 — The Questions You Are Terrified to Ask

```
BEFORE writing your interview script, answer this:

"What is the question I am most afraid to ask — because if the answer
 is 'no' or 'not really', my idea might be dead?"

Write it down. That question is the most important question in your interview.

EXAMPLES OF TERRIFYING QUESTIONS:
  "Is this problem painful enough that you would pay to solve it?"
  "Have you ever actually tried to solve this, or do you just complain about it?"
  "What would have to be true for you to switch from your current solution?"
  "What is the real reason you haven't fixed this yet?"

YOUR TERRIFYING QUESTION: [write it here, before anything else]

If you cannot think of a terrifying question, you have not understood
what you are actually risking. Go back and think harder.
```

---

## Step 2 — Design the Interview Script

```
INTERVIEW STRUCTURE (30–45 minutes total):

PHASE 1 — THE WARM-UP (5 min)
  Goal: get them talking about their life, not your idea.
  Never mention your idea in this phase.

  OPENER: "I'm trying to understand how [people like you] handle [broad topic].
           I'm not selling anything — I'm just trying to learn.
           Can you tell me about your current process for [area]?"

  FOLLOW-UP PROMPTS:
    "Walk me through the last time that happened."
    "And then what did you do?"
    "How often does that come up?"

PHASE 2 — THE PROBLEM ZONE (15 min)
  Goal: find out if the problem is real, frequent, and painful enough to pay for.

  QUESTIONS (pick 3–4, adapt to your niche):

  ON FREQUENCY:
    "How often do you deal with [problem area]?"
    "When did this last come up for you?"
    "Is this a daily thing, weekly, or occasional?"

  ON PAIN LEVEL:
    "On a scale of annoyance — does this keep you up at night,
     or is it just mildly inconvenient?"
    "What does it cost you when this doesn't work well?
     (Time? Money? Stress?)"
    "If you could fix one thing about how you handle [problem], what would it be?"

  ON CURRENT SOLUTIONS:
    "What do you currently do when [problem] comes up?"
    "Have you tried anything to fix it? What happened?"
    "What do you use right now for [related task]? How much does it cost?"
    "What do you hate about what you're currently using?"

  ON PAST BEHAVIOUR (the gold):
    "Have you ever paid for something to solve this? What was it?"
    "Have you ever tried to find a tool for this and given up? What happened?"
    "What workarounds have you built for yourself?"
    (Workarounds = strong validation signal. People only build workarounds
     for genuinely painful problems.)

PHASE 3 — THE COMMITMENT TEST (10 min)
  Goal: test whether this is a real problem or just a topic they enjoy discussing.

  THE COMMITMENT QUESTION:
    "This has been super helpful. I'm building something that might help with
     [specific thing they mentioned]. I'd love to show you an early version.
     Would you be willing to [specific commitment]?"

  VALID COMMITMENTS (ranked by signal strength):
    1. Pay money right now (highest signal)
    2. Give you email to be first to know
    3. Intro to 3 other people who have this problem
    4. Agree to a 1-hour paid testing session
    5. Spend 30 minutes reviewing a mockup (lowest, but still real)

  INVALID "COMMITMENTS":
    "Sure, let me know when it's ready" → WORTHLESS
    "Send me a link when you launch" → WORTHLESS
    "I'll check it out" → WORTHLESS

  RULE: A commitment with no cost (time, money, reputation) is a compliment, not validation.

PHASE 4 — THE REFERRAL ASK (5 min)
  "Who else should I be talking to about this?
   Can you introduce me?"

  THE REFERRAL IS YOUR NEXT INTERVIEW.
  Every interview should generate 2–3 more interviews through referrals.
  If they will not refer you, that is also data.
```

---

## Step 3 — What to Listen For (Signal vs. Noise)

```
STRONG POSITIVE SIGNALS:
  ✓ Specific dollar amounts spent on current solutions
  ✓ Existing workarounds (spreadsheets, manual processes, hacks)
  ✓ Stories of lost time, money, relationships due to this problem
  ✓ Unprompted feature requests (they describe what they wish existed)
  ✓ Immediate referrals ("You need to talk to [name], this drives them crazy")
  ✓ Offers money or committed time before you pitch

WEAK SIGNALS (discount these heavily):
  ~ "That's interesting"
  ~ "I'd probably use something like that"
  ~ "Great idea, you should build it"
  ~ General enthusiasm without commitment
  ~ Positive responses that only appear AFTER you've pitched

RED FLAGS (rethink your idea):
  ✗ "I could just do that in [Excel / existing tool]"
  ✗ "It's not really that big a deal, I manage"
  ✗ No existing workaround (means problem is not painful enough to solve manually)
  ✗ Cannot name anyone else who has this problem
  ✗ Nobody has ever paid anything to solve this

FITZPATRICK'S PHRASE TO LISTEN FOR:
  "I wish someone would just..." → GOLD. This is their own product spec.
  Write it down verbatim. Use their exact words.
```

---

## Step 4 — Plan Your 5 Interviews

```
You need 5 interviews minimum before drawing any conclusions.
Not 50. Not 2. Five.

After 5 interviews, one of three things happens:
  A. Same problem keeps coming up → signal is real, proceed
  B. Different problems every time → you are talking to the wrong people
     OR the problem is not coherent. Reframe.
  C. Nobody has the problem you thought → pivot or abandon.

WHO TO INTERVIEW:
  Ideal: people who already experience the problem you are solving
  Good: people who work adjacent to the problem
  Avoid: friends and family (they lie most politely)
  Avoid: other entrepreneurs (they validate everything)

HOW TO FIND THEM:
  → Reddit (find the subreddit where your target hangs out)
  → LinkedIn (DM people with the right job title / situation)
  → Existing communities (Slack groups, Discord, Facebook groups)
  → Your own network — but only people who have the PROBLEM, not people who like you
  → Coffee shops, coworking spaces, industry events

THE ASK:
  "I'm researching how [people like you] handle [problem area].
   I'm not selling anything. I'd love 20 minutes of your time.
   Would you be up for a quick call?"

PLAN YOUR 5 INTERVIEWS:
  Person 1: [name / source / scheduled date]
  Person 2: [name / source / scheduled date]
  Person 3: [name / source / scheduled date]
  Person 4: [name / source / scheduled date]
  Person 5: [name / source / scheduled date]
```

---

## Step 5 — After Each Interview: The Debrief

```
DO THIS WITHIN 1 HOUR OF EACH INTERVIEW (before you forget):

FACTS (what actually happened, not interpretations):
  □ Quoted any specific amounts (time/money/frequency)?
  □ Described any workarounds?
  □ Mentioned any existing tools they pay for?
  □ Made any commitment?

SIGNALS (your interpretation of what it means):
  □ Strong signal (above), weak signal, or red flag?
  □ Did they confirm the problem is real and painful?
  □ Did anything surprise you?

QUESTIONS RAISED (things you need to test further):
  □ What do you now know that you did not know before?
  □ What new questions does this interview create?

PIVOTS (things you need to change about your idea):
  □ Did anything they said suggest you have the wrong problem,
    wrong audience, or wrong solution?

AFTER 5 INTERVIEWS: THE PATTERN REVIEW:
  Write down every fact across all 5 interviews.
  Look for things that came up 3 or more times.
  Those patterns are your validated learning.
  Single mentions are interesting. Patterns are signal.
```

---

## Output File: interview_plan.md

```markdown
# Interview Plan
Pipeline step: 2 of 6
Date: [date]
Idea being tested: [from angle_map.md]

---

## My Terrifying Question
[The one question that could kill the idea — write it here]

## Interview Script
[Paste your adapted script from Steps 2–3 above]

## Signal Scoring Guide
Strong signal : [list 3 things you will count as strong signals for this idea]
Weak signal   : [list 3 weak signals]
Red flag      : [list 3 red flags]

## Interview Log
| # | Person | Source | Date | Key fact | Signal (strong/weak/red) | Commitment? |
|---|--------|--------|------|----------|--------------------------|-------------|
| 1 |        |        |      |          |                          |             |
| 2 |        |        |      |          |                          |             |
| 3 |        |        |      |          |                          |             |
| 4 |        |        |      |          |                          |             |
| 5 |        |        |      |          |                          |             |

## Pattern Summary (after 5 interviews)
Came up 3+ times : [list]
Came up once     : [list]
Never came up    : [assumptions that weren't confirmed]

## Exact customer quotes (verbatim — these will become your marketing copy):
1. "[quote]"
2. "[quote]"
3. "[quote]"

## Verdict
[ ] PROCEED — problem is real, frequent, painful, people have paid to solve it
[ ] REFRAME — real problem, wrong audience or wrong framing
[ ] PIVOT   — different problem emerged that is bigger/more urgent
[ ] ABANDON — nobody has this problem at the level required

---

## Pipeline Status
Step 1 ✅ steal-the-angle   → angle_map.md
Step 2 ✅ mom-test-master   → interview_plan.md
Step 3 ⬜ assumption-killer → assumption_tests.md
Step 4 ⬜ mvp-sprint        → mvp_spec.md
Step 5 ⬜ message-maker     → message_kit.md
Step 6 ⬜ first-sale-engine → sales_plan.md
```

---

## Review Gate (MANDATORY)

After saving `interview_plan.md`, present this EXACTLY:

```
✅ Interview plan complete. Saved to interview_plan.md.

📋 Summary:
- Terrifying question : [the one question that matters]
- Interviews planned  : [N]
- Interviews completed: [N]
- Strong signals      : [N]
- Red flags           : [N]
- Best customer quote : "[verbatim quote]"
- Verdict             : PROCEED / REFRAME / PIVOT / ABANDON

👉 You can:
  - Approve → say "approved" or "kill assumptions"
  - Add interview notes → say "add interview: [person, key fact, signal]"
  - Request a reframe → say "reframe for [new audience / angle]"

⏸️ Waiting for approval before Assumption Killer runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `kill assumptions`, `assumption killer`,
`proceed`, `next`, `go`, `interviews done`, `test the assumptions`

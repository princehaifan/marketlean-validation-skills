---
name: first-sale-engine
description: >
  Step 6 of 6 in the Lean Validation Pipeline. Gets to the first paying
  customer using the validated message and MVP. Builds the outreach sequence,
  the sales conversation script, the launch plan for first 30 days, the
  pricing strategy, and the retention / referral flywheel. Applies Lean
  Startup engine-of-growth thinking to build a repeatable sales motion.
  Saves as sales_plan.md.
---

# First Sale Engine

The first sale is the most important thing you will ever do for this business.
Not because of the money. Because it proves a real person
used real money to say "I believe you can solve my problem."
Everything before the first sale is theory. The first sale is evidence.
Most people spend months preparing to get ready to be ready to sell.
You are going to sell before you feel ready.
Feeling ready is not the prerequisite. Having a validated product
and a person with the problem is the prerequisite.
You have both. Now close. Save as `sales_plan.md`.

---

## Prerequisites

```
READ FIRST: interview_plan.md → the 5 people who confirmed the problem,
                                  their exact language, any who committed
READ SECOND: mvp_spec.md      → what you have to offer, the core promise
READ THIRD: message_kit.md    → your headline, landing page copy, the brief
```

---

## Step 1 — The Warm List (Your First 10 Customers Are Already Known)

```
THE RULE: Do not advertise before you have sold to people you can reach directly.

Your first customers are not strangers. They are:
  → People you interviewed (some made commitments)
  → Referrals from those interviews ("you should talk to [name]")
  → People in communities where you found your interview subjects
  → People who have the problem and know you exist

THE WARM LIST EXERCISE:
  Write down every person who:
    a) Confirmed they have the problem (from your interviews)
    b) Said something like "let me know when it's ready"
    c) Was referred to you by an interviewee
    d) Has the same profile as your interview subjects and you can reach them

  List them: [Name | How they know you | What they said | Contact method]

THE PRIORITY ORDER:
  1. People who made a commitment in an interview (highest)
  2. Referrals from committed people
  3. Community members who engaged with your research
  4. Cold outreach to people who match the profile exactly

START WITH 1. NOT 4.
```

---

## Step 2 — The Outreach Sequence (Getting the Conversation)

```
THE OUTREACH GOAL: One conversation. Not a sale.
Never try to sell in the first message.
Get the reply. Then get the conversation. Then sell.

MESSAGE TYPE 1 — FOLLOW-UP TO AN INTERVIEWEE:
  Subject: "[Their first name] — it is ready"

  Body:
  "Hi [name],

  You were one of the first people I spoke to about [problem area].
  What you told me about [specific thing they said] really shaped what I built.

  I have a working version. It [does the specific thing they said they needed].

  I would love to show you and get your honest reaction.
  Would 20 minutes work this week?

  [Your name]"

  RULES:
    → Reference something specific they said
    → Do not describe the whole product
    → Ask for 20 minutes, not "would you buy it"
    → Short. Under 100 words.

MESSAGE TYPE 2 — COLD OUTREACH (target match, no prior contact):
  Subject: "Quick question about [their specific situation]"

  Body:
  "Hi [name],

  I noticed [specific thing about them — job title, post they made, community they are in].

  I am building a [one-line description] for [specific audience].
  I have talked to about [N] people in [community/role] about [problem area].

  Most of them said [paraphrase of main pain point].
  Does that match your experience?

  [Your name]"

  RULES:
    → Never pitch in cold message #1
    → Ask ONE question that invites a yes/no or one-sentence reply
    → Show you know their world specifically
    → Under 80 words

FOLLOW-UP SEQUENCE (if no reply after 3–5 days):
  Message 2: "One thing I noticed [relevant observation] — wondered if
              this matched what you deal with?"
  Message 3: "[Short, direct] "Still relevant? Happy to chat or not.
              Either way, no worries."
  After 3 messages with no reply: move on.
```

---

## Step 3 — The Sales Conversation Script

```
THE STRUCTURE OF A SALES CONVERSATION (20–30 minutes):

PHASE 1 — RECONNECT AND LISTEN (5 min)
  "Before I show you what I built, can I ask — has [the problem we talked about]
   come up for you recently? What happened?"

  Let them talk. Listen for:
  → Confirmation the problem is still active
  → New context that might affect your pitch
  → Language you can use later in the conversation

PHASE 2 — SHOW THE MVP (10 min)
  "Great. Let me show you what I built based on what you and others told me."

  Walk through the MVP. Focus on:
  → The moment they described in the interview
  → The specific frustration your product eliminates
  → One specific result they will get

  THE DEMO RULE: show the core value in under 5 minutes.
  If you need more than 5 minutes to show the value, the value is not clear enough.

PHASE 3 — THE DIRECT ASK (5 min)
  "Based on what you've seen — does this solve the problem you described to me?"

  WAIT FOR THEIR ANSWER.

  If YES:
    "I am charging $[price] for access. That includes [specific things].
     Would you like to get started?"

  If MAYBE or "it's good but...":
    "What would need to be different for it to be a clear yes?"
    → Write down exactly what they say
    → If you can fix it quickly: "I can have that in [days]. If I do that,
       would you buy then?"
    → If you cannot fix it: "That's really helpful. Can I follow up when
       I've built that feature?"

  If NO:
    "That is really useful to hear. Can you tell me more about what did
     not work for you?"
    → This is a free consulting session. Never end it early.

THE CLOSING QUESTION (use this exact phrase):
  "I'd love to have you as one of the first people to use this.
   Can I send you the payment link?"

NOT: "What do you think?"
NOT: "Would you be interested?"
YES: "Can I send you the payment link?"

The direct ask removes ambiguity. It forces a real answer.
A polite "maybe" is not a sale. A direct "yes" to a payment link is.
```

---

## Step 4 — Pricing Strategy

```
THE LEAN STARTUP RULE ON PRICING:
  If nobody says the price is too high, it is too low.
  Charge more than feels comfortable.

THE MOM TEST RULE ON PRICING:
  Never ask "how much would you pay?"
  Observe what they currently pay for the problem.
  Price at or above what they pay for the inferior solution.

PRICING PRINCIPLES:

  PRINCIPLE 1: You are not competing on price.
    You are competing on value. If you compete on price,
    you will always lose to a larger competitor who can go lower.

  PRINCIPLE 2: Price signals quality.
    A $5 product is perceived as a $5 solution.
    A $97 product is perceived as something worth protecting.
    Free is perceived as worthless.

  PRINCIPLE 3: The first price is a test, not a commitment.
    Launch at a price. Raise it after the first 10 sales.
    Every price change is a test. Document what happens to conversion.

  PRINCIPLE 4: Charge before you have social proof.
    You do not need 500 testimonials to charge $97.
    You need a promise you can keep and a person with the problem.

PRICING TIERS (optional — for when you have validation and want to grow):

  ENTRY: [low commitment, lowest price, highest volume]
    Example: single product, no support, $X
    Goal: get people in the door, collect feedback, build social proof

  CORE: [main product, main price, main audience]
    Example: product + tutorial + updates, $X
    Goal: this is your primary revenue driver

  PREMIUM: [most value, highest price, lowest volume]
    Example: product + 1:1 setup + priority support, $X
    Goal: capture high-willingness-to-pay buyers without blocking volume buyers

YOUR LAUNCH PRICE: $[X]
  Justify it in one sentence: [why this number, not the one above or below]
  Raise-price trigger: [after N sales, or after N days, or after first testimonial]
```

---

## Step 5 — The 30-Day Launch Plan

```
WEEK 1 — CLOSE THE WARM LIST:
  Day 1–2: Send personal outreach to everyone on your warm list (Step 1)
  Day 3–5: Follow up with any who did not reply
  Day 6–7: Run sales conversations with anyone who replied
  Goal: 2–5 paying customers from the warm list
  Revenue: $[X]

WEEK 2 — EXPAND TO COMMUNITY:
  Day 8–10: Post in the Reddit / community / Slack where your audience lives
            Post format: share what you learned, offer something useful, 
            mention the product at the end or in the comments
  Day 11–12: DM people who engaged with the community post
  Day 13–14: Run sales conversations
  Goal: 3–7 more paying customers
  Revenue: $[X]

WEEK 3 — LAUNCH THE LANDING PAGE:
  Day 15: Publish landing page (copy from message_kit.md)
  Day 16–17: Share the landing page link in 3–5 relevant communities
             (with value-first context, not just a link drop)
  Day 18–20: Run a $20 test ad on the most relevant platform
             Measure: clicks, sign-ups, conversions
  Goal: validate the landing page conversion rate
  Revenue: $[X]

WEEK 4 — LEARN AND ADJUST:
  Day 21–25: Review all metrics. What worked? What did not?
             Which message drove the most conversations?
             Which channel brought the most willing buyers?
  Day 26–28: Double down on the highest-signal channel.
             Cut the lowest-signal channel.
  Day 29–30: Survey first customers: "What made you buy?"
             Use their words to update the landing page headline.
  Goal: repeatable sales motion identified
  Revenue: $[X]

30-DAY TOTAL REVENUE TARGET: $[X]
30-DAY CUSTOMER TARGET: [N]
30-DAY LEARNING TARGET: [what you will know that you do not know now]
```

---

## Step 6 — The Retention and Referral Flywheel

```
FROM RIES: There are three engines of growth.
  STICKY ENGINE: customers come back (retention drives growth)
  VIRAL ENGINE: customers bring new customers (referrals drive growth)
  PAID ENGINE: you buy customers (advertising drives growth)

Your first engine should be STICKY or VIRAL.
Do not use PAID until you have confirmed the first two work.
Paid engine amplifies an existing engine. It does not replace one.

STICKY ENGINE (retention):
  After purchase, what brings them back?
  → Updates / new content
  → A community of people using the product
  → A result that improves over time (the product gets better as they use it)
  → A habit loop built into the product

VIRAL ENGINE (referrals):
  What would make a customer share this with someone exactly like them?
  → The product is visibly impressive when used (others see it)
  → The product works better with more people (collaborative tools)
  → The founder actively asks for referrals at the moment of maximum happiness

THE REFERRAL ASK (do this at the moment of maximum happiness):
  → Right after they get their first result
  → Right after they leave a positive review
  → Right after they respond positively to your follow-up email

  EXACT SCRIPT:
  "So glad that is working for you. Quick question —
   do you know 2 or 3 other [people like them] who deal with the same thing?
   I would love to offer them [same thing / discount].
   Would you be comfortable making an intro?"

THE NPS QUESTION (Net Promoter Score):
  "On a scale of 0–10, how likely are you to recommend [product] to a friend?"
  Promoters (9–10): ask for the referral immediately
  Passives (7–8): ask what would make it a 9 or 10
  Detractors (0–6): ask what went wrong; fix it; check back in 30 days
```

---

## Output File: sales_plan.md

```markdown
# Sales Plan
Pipeline step: 6 of 6
Date: [date]
Product: [from mvp_spec.md]
Price: $[X]

---

## Warm List
| Name | How known | What they said | Contact | Priority |
|------|-----------|----------------|---------|----------|
[minimum 5 rows]

## Outreach Messages
Warm follow-up : [paste message]
Cold outreach  : [paste message]
Follow-up #2   : [paste message]

## Sales Conversation Script
Phase 1 opener      : [your reconnect question]
Demo focus          : [the specific moment you will show]
Direct ask          : [your closing question]
Objection response  : [most likely objection + answer]

## Pricing
Launch price        : $[X]
Justification       : [one sentence]
Tier structure      : Entry $[X] / Core $[X] / Premium $[X]
Raise trigger       : [condition]

## 30-Day Launch Plan
Week 1 goal         : [N customers from warm list] = $[X]
Week 2 goal         : [N customers from community] = $[X]
Week 3 goal         : [N from landing page] = $[X]
Week 4 goal         : [repeatable channel identified]
30-day total        : $[X] revenue, [N] customers

## Growth Engine
Primary engine      : STICKY / VIRAL / PAID
Retention mechanism : [how they come back]
Referral ask trigger: [the moment of maximum happiness]
NPS target          : 8+ average

## First Sale Date
Target              : [date]
Who it will be      : [name from warm list, if known]

---

## Pipeline Status
Step 1 ✅ steal-the-angle   → angle_map.md
Step 2 ✅ mom-test-master   → interview_plan.md
Step 3 ✅ assumption-killer → assumption_tests.md
Step 4 ✅ mvp-sprint        → mvp_spec.md
Step 5 ✅ message-maker     → message_kit.md
Step 6 ✅ first-sale-engine → sales_plan.md

🎉 Pipeline complete. All 6 steps done.
Now go get the first sale. Everything else is theory.
```

---

## Review Gate (MANDATORY)

After saving `sales_plan.md`, present this EXACTLY:

```
✅ Sales plan complete. Saved to sales_plan.md.

📋 Final Pipeline Summary:
- Idea validated  : [from steal-the-angle + mom test]
- Assumptions confirmed: [N of N]
- MVP type        : [type]
- Message         : [chosen headline]
- Warm list       : [N people]
- Launch price    : $[X]
- 30-day target   : $[X] from [N] customers
- First sale by   : [target date]

The full pipeline is complete.
You started with an idea. You now have:
  ✓ A validated unique angle
  ✓ Real customer language from real interviews
  ✓ Tested assumptions — no blind faith
  ✓ An MVP spec built for a real question
  ✓ Marketing copy in your customer's words
  ✓ A 30-day plan to the first sale

Go close the first one.

👉 You can:
  - Start selling → say "send outreach: [person name]"
  - Restart with a new idea → say "new idea: [description]"
  - Revisit any step → say "revisit [step name]"

⏸️ Pipeline complete. No further automatic steps.
```

**NEVER** proceed automatically.

Approval keywords: `send outreach`, `new idea`, `revisit`,
`done`, `complete`, `start over`, `first sale`

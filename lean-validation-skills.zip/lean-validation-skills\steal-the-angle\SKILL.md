---
name: steal-the-angle
description: >
  Step 1 of 6 in the Lean Validation Pipeline. Applies "Steal Like an Artist"
  to find your creative angle: map the landscape of what already works, trace
  your influences, identify the remix opportunity, and define the unique
  angle that is authentically yours. No blank-page thinking. Only intelligent
  theft. Saves findings as angle_map.md.
---

# Steal the Angle

"Steal Like an Artist" does not mean plagiarise.
It means: nothing comes from nothing. Every idea is a remix.
Good artists copy. Great artists steal. And great thieves study before they take.
Before you build anything, before you talk to anyone,
map the landscape of what already exists.
Find out who influenced the thing you want to build.
Find out what that thing influenced.
Then find the gap — the thing that exists in your head
but not yet in the world.
That gap is your angle. Save as `angle_map.md`.

---

## The Core Principle from Austin Kleon

```
"Your job is to collect good ideas. The more good ideas you collect,
 the more you can choose from to be influenced by."

WHAT THIS MEANS FOR A PRODUCT/BUSINESS:
  You are not trying to invent something from scratch.
  You are trying to find the best available version of your idea,
  study what makes it work, and then remix it into something
  that only you could build.

THE THREE-STEP CREATIVE THEFT:
  1. Find the work that excites you (the existing versions of your idea)
  2. Study it until you understand WHY it works
  3. Build the version that adds your unique contribution

THE REMIX IS NOT THE DESTINATION:
  The goal is not to build a copy. The goal is to understand the DNA
  so well that your version evolves it.
  "If you have one person you're influenced by, everyone will say
   you're the next whoever. But if you steal from 10 people,
   you'll be seen as something new." — Austin Kleon
```

---

## Step 1 — Name the Thing You Want to Build

```
WRITE THE IDEA IN ONE SENTENCE:
  "I want to build [X] for [who] that helps them [outcome]."

DO NOT WORRY YET IF:
  → It already exists
  → You are not sure if people want it
  → You cannot build it yet

Just name it. This is your starting hypothesis.

EXAMPLE:
  "I want to build a budgeting spreadsheet for freelancers
   that handles irregular income and auto-calculates tax set-asides."

YOUR IDEA:
  [fill in]
```

---

## Step 2 — Map the Landscape (Find Your Influences)

```
FIND 10 THINGS THAT ARE RELATED TO YOUR IDEA.
Not all will be direct competitors. Some are adjacent.
You are looking for the constellation of things that influenced your idea
even if unconsciously.

SOURCES TO SEARCH:
  Direct competitors: search "[your niche] tool" / "[problem] software"
  Adjacent products: what do your target users already use?
  Offline / analogue versions: how did people solve this before software?
  Inspiration: what made you think of this idea in the first place?
  Industries that solved a similar problem differently

FOR EACH THING, RECORD:
  Name: [product/book/service/approach]
  What it does well: [1–2 sentences]
  What is missing or broken: [1–2 sentences]
  Who uses it: [audience]
  Price: [if applicable]

BUILD THE 10-ITEM TABLE:
  | # | Name | Does well | Missing | Audience | Price |
  |---|------|-----------|---------|----------|-------|
  | 1 |      |           |         |          |       |
  ...
```

---

## Step 3 — Find the Lineage (Who Influenced Your Influences)

```
KLEON'S METHOD: "Climb up the tree."
When you find an artist/product you love, don't just study them.
Study who THEY stole from. Go one level up.

FOR YOUR BEST 3 INFLUENCES FROM STEP 2:

  Influence 1: [name]
  Who/what inspired them: [trace it back one level]
  Original idea: [what was the first version of this concept?]

  Influence 2: [name]
  Who/what inspired them: [trace it back]
  Original idea: [what was the first version?]

  Influence 3: [name]
  Who/what inspired them: [trace it back]
  Original idea: [what was the first version?]

WHY THIS MATTERS:
  When you understand the lineage, you stop feeling like an imposter.
  You are not copying. You are participating in an ongoing conversation
  that has been happening long before you arrived.
  Your job is to add one sentence to that conversation.
```

---

## Step 4 — Find the Gap (Your Remix Opportunity)

```
THE GAP IS WHERE YOUR PRODUCT LIVES.

Look at your 10 influences and answer:

  QUESTION 1: What is the best version of this idea I found?
    [name the product/approach]

  QUESTION 2: What does it do that nothing else does?
    [the thing that makes it the best]

  QUESTION 3: What does even the best version still NOT do?
    [the thing it cannot or will not solve]
    This is often the gap.

  QUESTION 4: What combination of two or more of my influences
    does not currently exist as a single product?
    Example: "[Product A]'s simplicity + [Product B]'s depth"

  QUESTION 5: What would only I build — given my unique background,
    knowledge, tools, and perspective?
    [your unfair advantage angle]

THE REMIX FORMULA:
  "Take [the best of X] + [the best of Y] + [remove the worst of both]
   + [add the thing only I know/can do] = my product"

YOUR REMIX STATEMENT:
  "[Product name] takes [X from influence 1] + [X from influence 2],
   removes [the common failure point], and adds [your unique contribution]."
```

---

## Step 5 — The Unique Angle Statement

```
ONE PARAGRAPH. Write who this is for, what it does,
why it is different, and why it is yours.

TEMPLATE:
  "[Product name] is a [type of product] for [specific audience]
   who struggle with [specific problem].
   Unlike [closest alternative], it [key difference].
   I am building this because [your genuine reason — your unfair advantage]."

THIS IS YOUR PITCH. NOT FOR INVESTORS.
For yourself. For your first customer conversation.
For the moment someone asks "so what do you do?"

MAKE IT SPECIFIC:
  BAD: "It's a productivity tool for busy people."
  GOOD: "It's a revenue tracker for freelance designers
         who invoice in multiple currencies and need to
         know their actual take-home in real time."
```

---

## Output File: angle_map.md

```markdown
# Angle Map
Pipeline step: 1 of 6
Date: [date]
Idea: [one-sentence idea]

---

## The Landscape (10 Influences)
| # | Name | Does well | Missing | Audience | Price |
|---|------|-----------|---------|----------|-------|
[fill in 10 rows]

## The Lineage (3 Influences Traced Back)
Influence 1: [name] ← [who inspired them] ← [original idea]
Influence 2: [name] ← [who inspired them] ← [original idea]
Influence 3: [name] ← [who inspired them] ← [original idea]

## The Gap Analysis
Best version found      : [name]
What makes it the best  : [1 sentence]
What it still cannot do : [1 sentence — your gap]
Combination that doesn't exist: [X from A + Y from B]
Your unfair advantage   : [what only you can bring]

## The Remix Statement
[Your formula: take X + take Y, remove Z, add your unique thing]

## The Unique Angle Statement
[Your one paragraph. Specific. Honest. Yours.]

---

## Pipeline Status
Step 1 ✅ steal-the-angle   → angle_map.md
Step 2 ⬜ mom-test-master   → interview_plan.md
Step 3 ⬜ assumption-killer → assumption_tests.md
Step 4 ⬜ mvp-sprint        → mvp_spec.md
Step 5 ⬜ message-maker     → message_kit.md
Step 6 ⬜ first-sale-engine → sales_plan.md
```

---

## Review Gate (MANDATORY)

After saving `angle_map.md`, present this EXACTLY:

```
✅ Angle map complete. Saved to angle_map.md.

📋 Summary:
- Idea                : [one sentence]
- Best influence found: [name]
- The gap             : [what nothing currently does]
- Your remix          : [formula]
- Unique angle        : [one sentence from angle statement]

👉 You can:
  - Approve → say "approved" or "run the mom test"
  - Add an influence → say "also map [product/book/approach]"
  - Refine the angle → say "sharpen the angle: [direction]"

⏸️ Waiting for approval before Mom Test Master runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `run the mom test`, `mom test`,
`proceed`, `next`, `go`, `angle approved`, `talk to customers`

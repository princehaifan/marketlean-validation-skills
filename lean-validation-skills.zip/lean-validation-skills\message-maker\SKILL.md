---
name: message-maker
description: >
  Step 5 of 6 in the Lean Validation Pipeline. Turns validated customer
  language (from Mom Test interviews) into marketing copy: headline, tagline,
  landing page, email subject lines, and ad creative. Uses the customer's
  exact words as the brief. Applies FastLane AI principles for speed-to-market.
  Saves as message_kit.md.
---

# Message Maker

Your best marketing copy is already written.
It is sitting in your interview notes.
When a customer said "I wish someone would just..." —
that is your headline.
When they described their frustration in their own words —
that is your landing page copy.
When they named the moment they needed help —
that is your ad.
Great marketing does not create desire. It reflects desire back at the person who already has it.
You are not writing copy. You are translating.
Save as `message_kit.md`.

---

## Prerequisites

```
READ FIRST: interview_plan.md   → customer quotes, exact verbatim language,
                                   patterns from 5 interviews
READ SECOND: angle_map.md       → unique angle statement, transformation
READ THIRD: mvp_spec.md         → what the product actually does, the promise
```

---

## Step 1 — Mine the Interview Notes for Copy Gold

```
THE RULE: Use their words, not yours.

You have been living with your idea for weeks or months.
You use jargon. You have opinions. You know too much.
Your customer uses normal language.
They describe their problem in the words they would type into Google.
Those words convert. Your words don't.

THE MINING EXERCISE:
From your interview_plan.md, extract:

  PAIN PHRASES (how they described the problem):
    "[exact quote describing their frustration]"
    "[exact quote describing what they currently do instead]"
    "[exact quote about what it costs them — time, money, stress]"

  DESIRE PHRASES (how they described what they want):
    "[exact quote about the outcome they want]"
    "[exact quote about what 'fixed' looks like for them]"
    "[exact quote beginning with 'I wish...' or 'I just want...']"

  IDENTITY PHRASES (how they described themselves):
    "[exact quote about who they are or what they do]"
    "[the label they used for people like them]"

  MOMENT PHRASES (the specific situation):
    "[exact quote describing when the problem hits]"
    "[exact quote about what triggers the need]"

THESE PHRASES ARE YOUR CREATIVE BRIEF.
Every piece of copy you write should use at least one of them verbatim
or be directly derived from them.
```

---

## Step 2 — The Headline Formula

```
THE ONE JOB OF A HEADLINE:
  Make the right person say "that's for me" in under 3 seconds.

NOT: be clever. Not: be funny. Not: be impressive.
Just: make the right person recognise themselves.

HEADLINE FORMULAS (write 5 versions using different formulas):

  FORMULA 1 — THE OUTCOME:
    "[Get/Achieve/Finally] [desired outcome] [without/even if] [common objection]"
    Example: "Finally know exactly where every dollar goes — without an accountant"

  FORMULA 2 — THE PROBLEM + SOLUTION:
    "[Specific problem] is [why]. [Product] fixes that."
    Example: "Tracking invoices across 3 currencies is a nightmare. We fix that."

  FORMULA 3 — THE WHO + WHAT:
    "For [specific person] who [specific situation]: [what it does]."
    Example: "For freelancers juggling multiple clients: one dashboard, all income, zero confusion."

  FORMULA 4 — THE DIRECT CLAIM:
    "[Specific measurable outcome] in [timeframe]."
    Example: "Know your real freelance income in 10 minutes a week."

  FORMULA 5 — THEIR OWN WORDS:
    Use the most powerful phrase from the interviews, slightly refined.
    Example (from interview: "I just want to know if I'm doing okay financially"):
    "Find out if your finances are actually okay — in under 10 minutes."

WRITE 5 HEADLINES NOW.
Then pick the one that sounds most like something a customer said.
Not the cleverest. The most recognisable.
```

---

## Step 3 — The Landing Page Structure

```
A LANDING PAGE IS A CONVERSATION WITH ONE PERSON.
Write it as if you are talking to the person from your best interview.

THE STRUCTURE (every element has one job):

  1. HEADLINE
     Job: make the right person say "that's for me"
     Use: your best headline from Step 2

  2. SUBHEADLINE (1–2 sentences)
     Job: explain how you deliver the headline's promise
     Use: a pain phrase + the mechanism that solves it
     Example: "Freelancers who juggle multiple clients, currencies and deadlines
               deserve a finance dashboard that actually makes sense.
               This is that dashboard."

  3. THE PROBLEM (1 short paragraph or 3 bullet points)
     Job: make them feel understood BEFORE you describe the solution
     Use: exact pain phrases from interviews
     Start with: "If you've ever..." or "You know the feeling when..."
     The goal: "Yes, they get it. This is exactly my situation."

  4. THE SOLUTION (what it does + how it works)
     Job: describe the mechanism, not the features
     Use: outcome language, not feature language
     NOT: "28-tab Google Sheet with automated formulas"
     YES: "Connect your income, your bills, and your goals in one place —
           and see exactly whether you're on track, without doing maths."

  5. WHAT IS INCLUDED (scannable bullets)
     Job: justify the price, reduce risk
     3–6 bullets, each ending in a benefit, not just a feature
     NOT: "Automated dashboard"
     YES: "Automated dashboard — see your numbers update in real time
           without touching a formula"

  6. SOCIAL PROOF (if you have it — if not, skip for now)
     Job: show that someone like them already trusted this
     Use: a quote from an interview participant (with permission)
          or a result from an MVP tester
     If no social proof yet: add "trusted by [N] people in early access"
     only if true.

  7. THE PRICE + CTA
     Job: convert
     Show the price clearly. Do not hide it.
     CTA button: active verb + the outcome
     NOT: "Buy now" or "Submit"
     YES: "Get instant access" / "Start tracking today" / "Download now"

  8. THE OBJECTION KILLER (FAQ or reassurance)
     Job: address the top 2–3 things that stop people from clicking
     Use: the objections that came up in interviews
     Examples: "Does this work on [platform]?" "What if I'm not technical?"
               "What if I don't like it?"
     Keep it short. 2–3 questions only.
```

---

## Step 4 — Email Subject Lines

```
THE EMAIL SUBJECT LINE HAS ONE JOB:
  Get the email opened. Not the sale. Just the open.

RULES:
  Under 50 characters if possible (shows fully on mobile)
  Specific beats clever
  Questions work (they create an open loop)
  Numbers work (they signal specificity)
  "You" > "We" (always)

WRITE 10 SUBJECT LINES (5 for cold / awareness, 5 for warm / existing list):

  COLD OUTREACH SUBJECTS:
    "[Pain phrase]?" (turns their problem into a question)
    "How [customer type] [solve problem]" (curiosity + identity)
    "[Number] [customer type] fixed [problem] with [approach]"
    "Quick question about [their situation]"
    "[Mutual connection / context] → [specific thing]"

  WARM LIST SUBJECTS:
    "Your [result] is ready"
    "[Feature/update] you asked for — it is live"
    "One thing most [customer type] get wrong about [topic]"
    "[Time-based trigger]: [relevant prompt]"
    "[Their name], [personalised signal]"

WRITE 10 NOW. Pick your top 3.
```

---

## Step 5 — Ad Creative Brief

```
AN AD HAS 3 JOBS IN 3 SECONDS:
  Second 1: Stop the scroll (image or first line)
  Second 2: Identify the person (make them feel seen)
  Second 3: Deliver a reason to click

THE SCROLL-STOPPER:
  Best scroll-stoppers are either:
  → A problem stated bluntly ("Tired of losing track of invoices?")
  → A result stated specifically ("Made $4,200 last month. Here's the breakdown.")
  → A moment they recognise ("When a client asks 'can you invoice in euros?' 😬")

FOR EACH AD FORMAT, WRITE:

  FACEBOOK / INSTAGRAM STATIC AD:
    Headline (above image or bold text): [1 line from headline formulas]
    Image concept: [describe what should be shown — the moment, not the product]
    Body (3 lines max): [problem → solution → CTA]
    CTA button: [text]

  SHORT-FORM VIDEO HOOK (first 3 seconds of a Reel / TikTok):
    Hook line (spoken or text overlay): [says the problem out loud]
    Visual: [what is happening on screen]
    Payoff: [what they see that makes them watch to the end]

  REDDIT / COMMUNITY POST:
    Title: [sounds like a person posting, not an ad]
    Format: Story → lesson → soft product mention
    Rule: lead with value. Product mention is secondary or in the comments.

  GOOGLE SEARCH AD:
    Headline 1 (30 chars): [most searched phrase + outcome]
    Headline 2 (30 chars): [differentiator]
    Description (90 chars): [benefit + CTA]
```

---

## Output File: message_kit.md

```markdown
# Message Kit
Pipeline step: 5 of 6
Date: [date]
Product: [from mvp_spec.md]

---

## Copy Gold (from interviews)
Pain phrases   :
  1. "[verbatim quote]"
  2. "[verbatim quote]"
Desire phrases :
  1. "[verbatim quote]"
  2. "[verbatim quote]"
Moment phrases :
  1. "[verbatim quote]"

## Headlines (5 versions)
1. [formula 1 — outcome]
2. [formula 2 — problem + solution]
3. [formula 3 — who + what]
4. [formula 4 — direct claim]
5. [formula 5 — their words]
CHOSEN HEADLINE: [which one and why]

## Landing Page Copy
Headline      : [chosen]
Subheadline   : [2 sentences]
Problem section:
  [paragraph or bullets using customer language]
Solution section:
  [mechanism, not features]
What's included:
  • [benefit bullet]
  • [benefit bullet]
  • [benefit bullet]
Price + CTA   : $[X] — [CTA button text]
Objection FAQ :
  Q: [objection 1] A: [answer]
  Q: [objection 2] A: [answer]

## Email Subject Lines
Top 3 cold    :
  1. [subject]
  2. [subject]
  3. [subject]
Top 3 warm    :
  1. [subject]
  2. [subject]
  3. [subject]

## Ad Creative Briefs
Facebook/Instagram: [brief]
Short-form video hook: [hook line + visual + payoff]
Reddit post title: [title]
Google ad: [H1 + H2 + Description]

---

## Pipeline Status
Step 1 ✅ steal-the-angle   → angle_map.md
Step 2 ✅ mom-test-master   → interview_plan.md
Step 3 ✅ assumption-killer → assumption_tests.md
Step 4 ✅ mvp-sprint        → mvp_spec.md
Step 5 ✅ message-maker     → message_kit.md
Step 6 ⬜ first-sale-engine → sales_plan.md
```

---

## Review Gate (MANDATORY)

After saving `message_kit.md`, present this EXACTLY:

```
✅ Message kit complete. Saved to message_kit.md.

📋 Summary:
- Best customer phrase : "[verbatim quote]"
- Chosen headline      : [headline]
- Landing page         : [DRAFTED / PENDING]
- Email subjects       : [N written]
- Ad briefs            : [N formats]

👉 You can:
  - Approve → say "approved" or "get the first sale"
  - Rewrite a headline → say "rewrite headline [N] for [new angle]"
  - Add more ad formats → say "add [format]"
  - Test a subject line → say "A/B test: [subject A] vs [subject B]"

⏸️ Waiting for approval before First Sale Engine runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `get the first sale`, `first sale engine`,
`proceed`, `next`, `go`, `message approved`, `close the first sale`
